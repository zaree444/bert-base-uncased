# Sentiment Analysis with Fine-Tuned BERT

This project fine-tunes a BERT model for binary sentiment classification (positive/negative).

## Folder Structure

- `scripts/train.py` - Model training script
- `scripts/gradio_ui.py` - Gradio UI for testing
- `requirements.txt` - Python dependencies
- `model/` - Saved model after training
- `data/` - Input data (to be added)

## Usage

1. Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```

2. Train the model:
    ```bash
    python scripts/train.py
    ```

3. Run the UI:
    ```bash
    python scripts/gradio_ui.py
    ```

## Notes

- Add your training data in `data/` folder.
- Trained model is saved in `model/` folder.
